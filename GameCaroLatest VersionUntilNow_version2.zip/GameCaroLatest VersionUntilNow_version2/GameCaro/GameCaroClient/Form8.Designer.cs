﻿namespace GameCaroClient
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            SuspendLayout();
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 192, 255);
            button4.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button4.ForeColor = Color.BlueViolet;
            button4.Location = new Point(705, 508);
            button4.Name = "button4";
            button4.Size = new Size(162, 47);
            button4.TabIndex = 4;
            button4.Text = "OK";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.BXH_01;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1066, 692);
            Controls.Add(button4);
            DoubleBuffered = true;
            Name = "Form8";
            Text = "Form8";
            ResumeLayout(false);
        }

        #endregion

        private Button button4;
    }
}