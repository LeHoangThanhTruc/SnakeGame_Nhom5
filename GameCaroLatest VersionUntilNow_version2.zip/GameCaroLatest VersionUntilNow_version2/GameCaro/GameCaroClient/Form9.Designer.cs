﻿namespace GameCaroClient
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button5 = new Button();
            SuspendLayout();
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(255, 192, 255);
            button5.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button5.ForeColor = Color.MediumOrchid;
            button5.Location = new Point(708, 509);
            button5.Name = "button5";
            button5.Size = new Size(158, 52);
            button5.TabIndex = 5;
            button5.Text = "OK";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // Form9
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.LS_01;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1066, 692);
            Controls.Add(button5);
            DoubleBuffered = true;
            Name = "Form9";
            Text = "Form9";
            ResumeLayout(false);
        }

        #endregion

        private Button button5;
    }
}